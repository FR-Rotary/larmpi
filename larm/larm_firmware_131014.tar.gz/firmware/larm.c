/*
	Alarm status
	Architecture: Atmel AVR atmega32u2
	Daniel Vindevåg, daniel@vindevag.com
	Board: Mattairtech MT-DB-U2

	PORTD0, LED, turn ON = high/one
	PORTD1, larm status input, ON = low/zero
	PORTD7, HWB input, Active = low/zero


	2012-02-20: Initial release
	2012-04-14: Minor fixes for enter bootloader/firmware update
	2012-07-08: Minor fixes for enter bootloader/firmware update
	2013-04-26: Update for changes in avrlibc regarding prog_char
				Updated to LUFA-130303
	2013-10-12: Minor fixes, LUFA-130901
*/


#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/power.h>
#include <util/delay.h>
#include "Descriptors.h"
#include "bootloader.h"


#define READCOUNT 20000			// Read input x times for status change
#define INPUT_BUFFER_LEN 20

const char ATSTATUS[] PROGMEM 		= "atstatus";
const char ON[] PROGMEM				= "ON";
const char OFF[] PROGMEM			= "OFF";
const char ATFLASH[] PROGMEM		= "atflash";
const char COMPILEDATE[] PROGMEM	= TIMESTAMP;
const char ATV[] PROGMEM			= "atv";
const char DFU_BOOTLOADER[] PROGMEM	= "Entering DFU bootloader...";
const char CRLF[] PROGMEM			= "\r\n";


USB_ClassInfo_CDC_Device_t VirtualSerial_CDC_Interface = {
  .Config = {
    .ControlInterfaceNumber   = 0,
    .DataINEndpoint           = {
	.Address          = CDC_TX_EPADDR,
	.Size             = CDC_TXRX_EPSIZE,
	.Banks            = 1,
    },
    .DataOUTEndpoint = {
      .Address          = CDC_RX_EPADDR,
      .Size             = CDC_TXRX_EPSIZE,
      .Banks            = 1,
    },
    .NotificationEndpoint = {
      .Address          = CDC_NOTIFICATION_EPADDR,
      .Size             = CDC_NOTIFICATION_EPSIZE,
      .Banks            = 1,
    },
  },
};


inline static void sendstr (char *s) {
	CDC_Device_SendString(&VirtualSerial_CDC_Interface, s);
}

inline static void sendchar (char c) {
	CDC_Device_SendByte(&VirtualSerial_CDC_Interface, c);
}

inline static void sendstr_P (const char *s) {
	char p;
	while ((p = pgm_read_byte_near(s++))) CDC_Device_SendByte(&VirtualSerial_CDC_Interface, p);
}



int main(void) {
	char input_buffer[INPUT_BUFFER_LEN] = "";
	char *p_input = &input_buffer[0];
	uint8_t input_complete = 0;
	uint8_t status = 0;

	check_bootloader();
	#ifdef CHECK_HWB
	check_hwb();
	#endif

	// Pull target /RESET and HWB line high
	AVR_RESET_LINE_DDR  |= AVR_RESET_LINE_MASK; 
	AVR_RESET_LINE_PORT |= AVR_RESET_LINE_MASK;
	HWB_DDR  |= HWB_MASK; 
	HWB_PORT |= HWB_MASK;

	// Watchdog, prescaler, IO and interrupts
	MCUSR &= ~(1 << WDRF);
	wdt_disable();
	clock_prescale_set(clock_div_1);
	//DDRD = 0b10000001;
	DDRD |= 1 << PD0;	// Led, output
	USB_Init();
	sei(); 

	for (;;) {
		int16_t ReceivedByte = CDC_Device_ReceiveByte(&VirtualSerial_CDC_Interface);
		if (!(ReceivedByte < 0)) {
			*p_input++ = (char)ReceivedByte;

			if (*(p_input-1) == '\n') {
				if (*(p_input-2) == '\r') {
					*(p_input-2) = 0;
				}
				*(p_input-1) = 0;
				input_complete = 1;
			} else {
				if ( (p_input - &input_buffer[0]) > (INPUT_BUFFER_LEN-2) ) {
					input_buffer[0] = 0;
					input_complete = 0;
					p_input = &input_buffer[0];
				}
			}
		}
		CDC_Device_USBTask(&VirtualSerial_CDC_Interface);
		USB_USBTask();


		if (input_complete) {

			// Status
			if (!strncmp_P(&input_buffer[0], &ATSTATUS[0], strlen_P(&ATSTATUS[0]))) {
				if (status)
					sendstr_P(&ON[0]);
				else  
					sendstr_P(&OFF[0]);
				sendstr_P(&CRLF[0]);
			}

			// Version
			if (!strncmp_P(&input_buffer[0], &ATV[0], strlen_P(&ATV[0]))) {
				sendstr_P(&COMPILEDATE[0]);
				sendstr_P(&CRLF[0]);
			}

			// Flash, load bootloader // echo "atflash" > /dev/larm
			if (!strncmp_P(&input_buffer[0], &ATFLASH[0], strlen_P(&ATFLASH[0]) )) {
				sendstr_P(&DFU_BOOTLOADER[0]);
				sendstr_P(&CRLF[0]);
				CDC_Device_USBTask(&VirtualSerial_CDC_Interface);
				CDC_Device_Flush(&VirtualSerial_CDC_Interface);
				for (uint8_t i = 0; i < 75; i++) { // wait 1,5s
					USB_USBTask();
					_delay_ms(20);
				}
				USB_Disable();
				boot_loader();
			}

			input_buffer[0] = 0;
			input_complete = 0;
			p_input = &input_buffer[0];
		}


		{	// Check status on PORTD1,
			static uint32_t count = 0;
			if ( (!(PIND & (1 << PD1))) != status ) {
				count++;
				if (count == READCOUNT) {
					status = !(PIND & (1 << PD1));
					if (status) {				// low/zero
						sendstr_P(&ON[0]);
						PORTD |= (1 << PD0);
					} else { 				// high/one
						sendstr_P(&OFF[0]);
						PORTD &= ~(1 << PD0);
					}
					sendstr_P(&CRLF[0]);
				}
			} else count = 0;
		}


	} // loop
}





/** Event handler for the library USB Configuration Changed event. */
void EVENT_USB_Device_ConfigurationChanged(void) {
	CDC_Device_ConfigureEndpoints(&VirtualSerial_CDC_Interface);
}

/** Event handler for the library USB Unhandled Control Request event. */
void EVENT_USB_Device_UnhandledControlRequest(void) {
	CDC_Device_ProcessControlRequest(&VirtualSerial_CDC_Interface);
}

/** Event handler for the library USB Connection event. */
void EVENT_USB_Device_Connect(void) {
}

/** Event handler for the library USB Disconnection event. */
void EVENT_USB_Device_Disconnect(void) {
}

/** Event handler for the library USB Control Request reception event. */
void EVENT_USB_Device_ControlRequest(void) {
	CDC_Device_ProcessControlRequest(&VirtualSerial_CDC_Interface);
}


