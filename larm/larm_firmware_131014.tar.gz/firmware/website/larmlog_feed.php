<?php

include('larm_config.php');

# Timezone offset
$x = localtime();
$tz = sprintf("%+03d%02d", ($x[8] + date("Z")/3600), date("Z")%60);
$rss_pubdate_format_php = "%a, %d %b %Y %H:%M:%S";

$query = "SELECT status, date_format(date, '%W %Y-%m-%d %H:%i') as time, UNIX_TIMESTAMP(date) as timestamp FROM larmlog ORDER BY -date LIMIT $limit_rss";

$DB =  mysql_connect($DBHOST, $DBUSER, $DBPASS);
mysql_select_db($DBNAME, $DB);
mysql_set_charset("utf8", $DB);
mysql_query("SET @@lc_time_names='" . $text["time_lang"] . "'", $DB);
$result = mysql_query($query) or die("Database error");

?>
<?xml version="1.0"?>
<rss version="2.0">
<channel>
<image>
  <link><?php echo $larm_log_link;?></link>
  <url><?php echo $rotarypub_logotype;?></url>
</image>
<title><?php echo $text["title"];?></title>
<description><?php printf($text["rss_descr"], $limit_rss);?></description>
<ttl><?php echo $ttl_rss;?></ttl>
<?php

    while ($row = mysql_fetch_array($result)) {
      echo "<item>\n";
      echo "  <title>" . $row["time"] . " | ";
      if ($row["status"] == 1) { 
	echo $text["on"];
      }
      if ($row["status"] == 0) { 
        echo $text["off"];
      }
      if ($row["status"] == -1) { 
	echo $text["unknown"];
      }
      echo "</title>\n";
      echo "  <link>$larm_log_link</link>\n";
      echo "  <larm>" . $row["status"] . "</larm>\n";
      echo "  <pubDate>" . strftime($rss_pubdate_format_php, $row["timestamp"]) . " $tz</pubDate>\n";
      echo "</item>\n";
    }
    mysql_close($DB);

?>
</channel>
</rss>
