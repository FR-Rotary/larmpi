<?php

$DBHOST = 'localhost';
$DBNAME = 'puben_http';
$DBUSER = 'puben_http';
$DBPASS = 'rockpullan';

$limit = 200;          # # of items in alarm log
$limit_rss = 10;       # # of items in RSS feed

$ttl_rss = 10;         # TTL in minutes for RSS feed
$ttl_smartphone = 500; # TTL in seconds for smartphone page
$ttl_log = 1800;       # TTL in seconds for alarm log

$larm_log_link = 'http://www.rotarypub.se/internt/larmlog.php';
$rotarypub_logotype = 'http://www.rotarypub.se/bilder/rotarypub-logga.png';
date_default_timezone_set('Europe/Stockholm');

$lang = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2) : 'en';
$text = alarmtext_i18n($lang);

// Returnerar array() med associativa textsträngar beroende på inparameter: 
// språk i ISO 639-1-format.
//
// Ger engelska strängar om inget specifikt anges, eller språket inte finns 
// översatt.
function alarmtext_i18n($lang_code='en') {
    switch ($lang_code)
    {
    case 'sv':
        $text = [
            'title'         => 'Larmlog Rotary Pub',
            'time_lang'     => 'sv_SE',
            'time'          => 'Tidpunkt',
            'status'        => 'Status',
            'week'          => 'Vecka', 
            'on'            => 'Larmat',
            'off'           => 'Avlarmat',
            'unknown'       => 'Okänt',
            'rss_descr'     => 'Här visas de %d senaste till- och frånslagen av larmet i Rotary Pub.',
            'title_on'      => 'Puben är larmad sedan',
            'title_off'     => 'Puben är avlarmad sedan',
            'title_unknown' => 'Pubens larmstatus är okänd sedan'];
        break;

    case 'de':
        $text = [
            'title'         => 'Alarmlog von Rotary Pub',
            'time_lang'     => 'de_DE',
            'time'          => 'Zeit',
            'status'        => 'Status',
            'week'          => 'Woche',
            'on'            => 'Alarm ein',
            'off'           => 'Alarm aus',
            'unknown'       => 'Unbekannt',
            'rss_descr'     => 'Hier ist die letzten %d Statusänderungen vom Alarm des Rotary Pubs angezeigt.',
            'title_on'      => 'Der Alarm ist aktiviert seit',
            'title_off'     => 'Der Alarm ist deaktiviert seit',
            'title_unknown' => 'Der Zustand des Alarms ist unbekannt seit'];
        break;

    case 'fr':
        $text = [
            'title'         => 'Journal d\'alarme Rotary Pub',
            'time_lang'     => 'fr_FR',
            'time'          => 'Temps',
            'status'        => 'État',
            'week'          => 'Semaine',
            'on'            => 'Alarme activé',
            'off'           => 'Alarme désactivé',
            'unknown'       => 'Inconnu',
            'rss_descr'     => 'Voici les %d dernières modifications de l\'état de l\'alarme de la Rotary Pub.',
            'title_on'      => 'L\'alarme est active depuis',
            'title_off'     => 'L\'alarme est inactive depuis',
            'title_unknown' => 'L\'état d\'alarme est inconnu depuis'];
        break;

    case 'en':
    default:
        $text = [
            'title'         => 'Alarm Log Rotary Pub',
            'time_lang'     => 'en_US',
            'time'          => 'Time',
            'status'        => 'Status',
            'week'          => 'Week',
            'on'            => 'Armed ',
            'off'           => 'Disarmed',
            'unknown'       => 'Unknown',
            'rss_descr'     => 'List of the last %d status changes for the alarm in Rotary Pub.',
            'title_on'      => 'The pub alarm is armed since',
            'title_off'     => 'The pub alarm is disarmed since',
            'title_unknown' => 'The alarm state of the pub is unknown since'];
    }
    return $text;
}

// Returnerar array(int larmstatus [-1,0,1], str [tid för status])
function larmstatus() {
    global $DBHOST, $DBNAME, $DBUSER, $DBPASS, $text;

    $mysqli = new mysqli($DBHOST, $DBUSER, $DBPASS, $DBNAME);
    $mysqli->set_charset('utf8');
    $query = $mysqli->prepare('SET @@lc_time_names='.$text['time_lang']);
    $query->execute();
    $query = $mysqli->prepare('SELECT `status`, DATE_FORMAT(`date`, "%W %Y-%m-%d %H:%i") as `time` FROM `larmlog` ORDER BY `date` DESC LIMIT 1');
    $query->bind_result($status, $time);
    $query->execute();
    $query->fetch();
    $query->close();

    return(array($status, $time));
}

