<?php
#
# (c) Daniel vindevåg, daniel@vindevag.se, 2012 

include('larm_config.php');

$query = "SELECT status, date_format(date, '%W %Y-%m-%d %H:%i') as time, WEEK(date,3) as wk, YEAR(date) as yr, DAY(date) as day FROM larmlog ORDER BY -date LIMIT $limit";

$DB =  mysql_connect($DBHOST, $DBUSER, $DBPASS);
mysql_select_db($DBNAME, $DB);
mysql_query("SET NAMES UTF8", $DB);
mysql_query("SET @@lc_time_names='" . $text["time_lang"] . "'", $DB);
$result = mysql_query($query, $DB) or die("Database error");


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<html><head>
<!-- 
(c) Daniel Vindevåg, daniel at vindevag dot se, 2012

-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Refresh" content="<?php echo $ttl_log;?>">
<meta http-equiv="Pragma" content="no-cache">
<title><?php echo $text["title"] ?></title>


<style type="text/css">
body { 
  background-color:#cfd9da;
  font-size: 12px;
  font-family: verdana, arial, helvetica, sans-serif
}

.right { text-align:right;}

table {
  border:0px;  
  width:100%; 
}

tr.title {  
  background-color:#9c3031; 
  font-weight:bold;
  color:#ffffff; 
  font-size:18px;
}

tr.data {
  font-size: 12px;
  background-color:#f9f5f5;
}

td.header1 {  width:200px; font-weight:bold; font-size: 14px; }
td.header2 {  width:*; font-weight:bold; font-size: 14px;}

td.on { color:red;}
td.off { color:green }
td.unknown {  }
		   
tr.week { font-weight:bold; font-size: 14px; }
tr.blank { }

</style>
</head>


<body>

<table>
<tr class='title'><td colspan="2"><?php echo $text["title"] ?></td></tr>
<tr><td colspan="2"></td></tr>

<!--
  <tr><td colspan="2">
  <a href="larmlog_feed.php">RSS feed</a> (TTL 10 min)
  <a href="/larm/">Smartphone</a> page
  <a href="javascript:void(window.open('/larm/','larm_popup','resizable,location=no,menubar=no,status=no,toolbar=no,width=250,height=150,top=100,left=100'))">Popup</a> window (reload 5 min)
  </td></tr> 

  <tr><td colspan=2</td></tr><td colspan=2</td><tr></tr><tr><td colspan=2</td></tr> -->

<tr class='header'>
  <td class='header1'><?php echo $text["time"] ?></td>
  <td class='header2'><?php echo $text["status"] ?></td>
</tr> 


<tbody>
<?php
    $empty_row = "<tr><td colspan=2></td></tr>\n";
    $week = 0;
    $day = 0;
    while ($row = mysql_fetch_array($result)  ) {
      if ($row["wk"] == 0) { break; }  # SQL bug, shouldn't be needed
      if ($row["wk"] != $week) {
	$week = $row["wk"];
        echo $empty_row . $empty_row . $empty_row;
        echo "<tr class='week'><td>" . $text["week"];
        echo " $week  " . $row["yr"] . "</td><td></td></tr>\n";
      }
      if ($row["day"] != $day) {
	echo $empty_row;
	$day = $row["day"]; 
      }
      echo "\t<tr class='data'><td>" . $row["time"] . "</td>";
      if ($row["status"] == 1 ) echo "<td class='on'>" . $text["on"];  
      if ($row["status"] == 0 ) echo "<td class='off'>" .  $text["off"];
      if ($row["status"] == -1) echo "<td class='unknown'>".$text["unknown"];
      echo "</td></tr>\n";
    }
    mysql_close($DB);
?>

<tr><td colspan="2"></td></tr>
<tr><td colspan="2"><hr></td></tr>
<tr><td colspan="2" class='right'> <a href="/internt">Main</a></td></tr> 
<tr><td colspan="2"></td></tr>
</tbody>
</table>

</body></html>
