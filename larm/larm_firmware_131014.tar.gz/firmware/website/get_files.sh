#!/bin/sh

scp -p  "puben-http@in.rot.sgsnet.se:/home/puben-http/public/internt/larm/* /home/puben-http/bin/online.pl" .
