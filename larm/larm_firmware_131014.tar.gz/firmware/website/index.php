<?php

include('larm_config.php');
list($status, $time) = larmstatus();

switch ($status) {
	case 1:
		$color = 'red';
		$status_title = $text["title_on"];
		$status_text = $text["on"];
		break;
	case 0:
		$color = 'green';
		$status_title = $text["title_off"];
		$status_text = $text["off"];
		break;
	case -1:
		$color = 'white';
		$status_title = $text["title_unknown"];
		$status_text = $text["unknown"];
		break;
}

?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $status_title . " " . $time;?></title>
	<meta charset="utf-8" />
	<meta http-equiv="Refresh" content="<?php echo $ttl_smartphone;?>" />
	<meta http-equiv="Pragma" content="no-cache" />
	<style type="text/css">
                body 	{ background-color: <?php echo $color;?>;}
		p	{ display: block; margin: 0;}
                a       { text-decoration:none; color: black; }
		#status	{font-size: 36pt; }
		#time	{font-size: 18pt;}
	</style>
</head>

<body>
 <a id="background" href="larmlog.php"> 
  <p id="status"><?php echo $status_text;?></p>
  <p id="time"><?php echo $time;?></p>
 </a>
</body>
</html>
