#! /usr/bin/perl 

# Scriptet kollar om pubdatorn är igång, ifall den varit nere två gånger
# i rad rapporteras larmstatus som okänt (-1).
# Körs via crontab var 5:e minut.
#
# */5 * * * *   /home/puben-http/bin/online.pl  


use strict;
use DBI;

my $DBHOST = "localhost";
my $DBNAME = "puben_http";
my $DBUSER = "puben_http";
my $DBPASS = "rockpullan";

my $sql_insert = "INSERT INTO larmlog VALUES (null, now()-interval 10 minute, -1)";
my $sql_select = "SELECT date_format(date, '%a %b %e %H:%i'), status FROM larmlog ORDER BY -date LIMIT 1";

my $host = "192\.168\.5\.13";
#$host = "192\.168\.5\.2"; # for testing
my $ping_packets = 5;
my $dir = "/home/puben-http/bin";
my $downfile = "$dir/rockpullan-is-down";
my $downlog = "$dir/downlog.txt";
my $down_and_reported = "$dir/.rockpullan-is-down";
my $ping = "/bin/ping";
my $date = "/bin/date";


## Check if down
if (system("$ping -c $ping_packets -w $ping_packets -n -q $host >/dev/null")) {
	if (-e "$downfile") {
		if (! (-r $down_and_reported) ) {
			# Host down for the second time --> log an update db
			system("$date '+%a %Y-%m-%d %H:%M:%S %Z: Down' >> $downlog");
			my $db = DBI->connect("DBI:mysql:$DBNAME:$DBHOST", $DBUSER, $DBPASS);
			if (!$db) { 
				undef $db; 
				exit;
			}
			$DBI::result = $db->prepare($sql_select);
			$DBI::result->execute();
			my ($db_time, $db_status) = $DBI::result->fetchrow_array;
			$DBI::result->finish();
			if ($db_status != -1) {
				$DBI::result = $db->prepare($sql_insert);
				$DBI::result->execute();
				$DBI::result->finish();
			}
			$db->disconnect;
			undef $db;
			system("touch $down_and_reported");
		}
	} else {
		# Host is down now but up last time. Wait until next time.
		system("touch $downfile");
    }
} else {
	# Host is up, remove downfile
	if (-e "$downfile") { unlink "$downfile"; } 
	if (-e "$down_and_reported") { 
		unlink "$down_and_reported"; 
		system("$date '+%a %Y-%m-%d %H:%M:%S %Z: Up' >> $downlog");
    }
}

