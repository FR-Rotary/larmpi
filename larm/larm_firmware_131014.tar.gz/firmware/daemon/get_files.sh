#!/bin/sh

scp -p -P 10022 "rockpullan@in.rot.sgsnet.se:/home/rockpullan/bin/larm/90-larm-cdc.rules /home/rockpullan/bin/larm/larmd /home/rockpullan/bin/larm/init.larmd /home/rockpullan/bin/larm/info.txt" .
